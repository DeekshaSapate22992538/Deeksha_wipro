#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <unistd.h>

#define MAX 256  // Increased buffer size
#define PORT 8080
#define SA struct sockaddr

void perform_calculation(int sockfd) {
    char buff[MAX];
    float num1, num2;
    int choice;

    // Display options for calculation
    bzero(buff, MAX);
    read(sockfd, buff, sizeof(buff));
    printf("%s", buff);

    // Read user choice
    bzero(buff, MAX);
    fgets(buff, MAX, stdin);
    buff[strcspn(buff, "\n")] = 0;  // Remove newline character
    write(sockfd, buff, strlen(buff));

    // Handle calculations based on choice
    if (buff[0] >= '1' && buff[0] <= '5') {  // For choices 1 to 5
        printf("Enter two numbers:\n");
        bzero(buff, MAX);
        fgets(buff, MAX, stdin);
        buff[strcspn(buff, "\n")] = 0;  // Remove newline character
        write(sockfd, buff, strlen(buff));
        bzero(buff, MAX);
        fgets(buff, MAX, stdin);
        buff[strcspn(buff, "\n")] = 0;  // Remove newline character
        write(sockfd, buff, strlen(buff));
    } else if (buff[0] == '6') {  // For square root
        printf("Enter a number:\n");
        bzero(buff, MAX);
        fgets(buff, MAX, stdin);
        buff[strcspn(buff, "\n")] = 0;  // Remove newline character
        write(sockfd, buff, strlen(buff));
    } else {
        printf("Invalid option\n");
        return;
    }

    // Read and display the result
    bzero(buff, MAX);
    read(sockfd, buff, sizeof(buff));
    printf("From Server: %s", buff);
}



void chat(int sockfd) {
    char buff[MAX];

    while (1) {
        bzero(buff, MAX);
        printf("Enter message: ");
        fgets(buff, MAX, stdin);
        buff[strcspn(buff, "\n")] = 0;  // Remove newline character
        write(sockfd, buff, strlen(buff));
        if (strncmp("exit", buff, 4) == 0) {
            printf("Exiting chat...\n");
            break;
        }
        bzero(buff, MAX);
        read(sockfd, buff, sizeof(buff));
        printf("From Server: %s", buff);
    }
}

int main() {
    int sockfd;
    struct sockaddr_in servaddr;
    int choice;
    char buff[MAX];

    // Create socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("Socket creation failed...\n");
        exit(0);
    } else
        printf("Socket successfully created..\n");

    bzero(&servaddr, sizeof(servaddr));

    // Assign IP, PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(PORT);

    // Connect to server
    if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) {
        printf("Connection with the server failed...\n");
        exit(0);
    } else
        printf("Connected to the server..\n");

    while (1) {
        printf("Choose option:\n");
        printf("1. Chat\n");
        printf("2. Calculator\n");
        printf("3. Quit\n");
        printf("Enter choice: ");
        fgets(buff, MAX, stdin);
        buff[strcspn(buff, "\n")] = 0;  // Remove newline character
        write(sockfd, buff, strlen(buff));
        sscanf(buff, "%d", &choice);

        switch (choice) {
            case 1:
                chat(sockfd);
                break;
            case 2:
                perform_calculation(sockfd);
                break;
            case 3:
                close(sockfd);
                exit(0);
            default:
                printf("Invalid option\n");
                break;
        }
    }

    // Close socket
    close(sockfd);
    return 0;
}
