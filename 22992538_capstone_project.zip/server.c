#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <unistd.h>
#include <math.h>

#define MAX 256  // Increased buffer size
#define PORT 8080
#define SA struct sockaddr

void log_calculation(const char *operation, float num1, float num2, float result) {
    FILE *file = fopen("calculations.log", "a");
    if (file == NULL) {
        perror("Unable to open file");
        return;
    }
    fprintf(file, "Operation: %s\n", operation);
    fprintf(file, "Operand 1: %.2f\n", num1);
    fprintf(file, "Operand 2: %.2f\n", num2);
    fprintf(file, "Result: %.2f\n", result);
    fprintf(file, "--------------------------\n");
    fclose(file);
}

void log_chat(const char *from, const char *message) {
    FILE *file = fopen("chat.log", "a");
    if (file == NULL) {
        perror("Unable to open file");
        return;
    }
    fprintf(file, "%s: %s\n", from, message);
    fclose(file);
}

void perform_calculation(int connfd) {
    char buff[MAX];
    float num1, num2, result;
    int choice;

    // Display options for calculation
    snprintf(buff, sizeof(buff), "Choose operation:\n"
                                 "1. Addition\n"
                                 "2. Subtraction\n"
                                 "3. Multiplication\n"
                                 "4. Division\n"
                                 "5. Percentage\n"
                                 "6. Square root\n");
    write(connfd, buff, strlen(buff));

    // Read user choice
    bzero(buff, MAX);
    read(connfd, buff, sizeof(buff));
    sscanf(buff, "%d", &choice);

    // Handle calculations based on choice
    switch (choice) {
        case 1: // Addition
            bzero(buff, MAX);
            read(connfd, buff, sizeof(buff));
            sscanf(buff, "%f", &num1);
            bzero(buff, MAX);
            read(connfd, buff, sizeof(buff));
            sscanf(buff, "%f", &num2);
            result = num1 + num2;
            snprintf(buff, sizeof(buff), "Result: %.2f", result);
            log_calculation("Addition", num1, num2, result);
            break;
        case 2: // Subtraction
            bzero(buff, MAX);
            read(connfd, buff, sizeof(buff));
            sscanf(buff, "%f", &num1);
            bzero(buff, MAX);
            read(connfd, buff, sizeof(buff));
            sscanf(buff, "%f", &num2);
            result = num1 - num2;
            snprintf(buff, sizeof(buff), "Result: %.2f", result);
            log_calculation("Subtraction", num1, num2, result);
            break;
        case 3: // Multiplication
            bzero(buff, MAX);
            read(connfd, buff, sizeof(buff));
            sscanf(buff, "%f", &num1);
            bzero(buff, MAX);
            read(connfd, buff, sizeof(buff));
            sscanf(buff, "%f", &num2);
            result = num1 * num2;
            snprintf(buff, sizeof(buff), "Result: %.2f", result);
            log_calculation("Multiplication", num1, num2, result);
            break;
        case 4: // Division
            bzero(buff, MAX);
            read(connfd, buff, sizeof(buff));
            sscanf(buff, "%f", &num1);
            bzero(buff, MAX);
            read(connfd, buff, sizeof(buff));
            sscanf(buff, "%f", &num2);
            if (num2 != 0)
                result = num1 / num2;
            else {
                snprintf(buff, sizeof(buff), "Error: Division by zero");
                write(connfd, buff, strlen(buff));
                return;
            }
            snprintf(buff, sizeof(buff), "Result: %.2f", result);
            log_calculation("Division", num1, num2, result);
            break;
        case 5: // Percentage
            bzero(buff, MAX);
            read(connfd, buff, sizeof(buff));
            sscanf(buff, "%f", &num1);
            bzero(buff, MAX);
            read(connfd, buff, sizeof(buff));
            sscanf(buff, "%f", &num2);
            result = (num1 * num2) / 100;
            snprintf(buff, sizeof(buff), "Result: %.2f", result);
            log_calculation("Percentage", num1, num2, result);
            break;
        case 6: // Square root
            bzero(buff, MAX);
            read(connfd, buff, sizeof(buff));
            sscanf(buff, "%f", &num1);
            if (num1 >= 0)
                result = sqrt(num1);
            else {
                snprintf(buff, sizeof(buff), "Error: Negative input for square root");
                write(connfd, buff, strlen(buff));
                return;
            }
            snprintf(buff, sizeof(buff), "Result: %.2f", result);
            log_calculation("Square root", num1, 0, result);
            break;
        default:
            snprintf(buff, sizeof(buff), "Invalid option");
            break;
    }
    write(connfd, buff, strlen(buff));
}

void chat(int connfd) {
    char buff[MAX];

    while (1) {
        bzero(buff, MAX);
        read(connfd, buff, sizeof(buff));
        if (strncmp("exit", buff, 4) == 0) {
            printf("Client exited chat.\n");
            log_chat("Client", "Exited chat");
            break;
        }
        printf("From client: %s\n", buff);
        log_chat("Client", buff);

        printf("To client: ");
        bzero(buff, MAX);
        fgets(buff, MAX, stdin);
        buff[strcspn(buff, "\n")] = 0;  // Remove newline character
        write(connfd, buff, strlen(buff));
        log_chat("Server", buff);
    }
}

int main() {
    int sockfd, connfd, len;
    struct sockaddr_in servaddr, cli;

    // Create socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("Socket creation failed...\n");
        exit(0);
    } else
        printf("Socket successfully created..\n");

    bzero(&servaddr, sizeof(servaddr));

    // Assign IP, PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // Bind socket to IP and PORT
    if (bind(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) {
        printf("Socket bind failed...\n");
        exit(0);
    } else
        printf("Socket successfully binded..\n");

    // Listen for incoming connections
    if (listen(sockfd, 5) != 0) {
        printf("Listen failed...\n");
        exit(0);
    } else
        printf("Server listening..\n");

    len = sizeof(cli);

    // Accept incoming connection
    connfd = accept(sockfd, (SA*)&cli, &len);
    if (connfd < 0) {
        printf("Server accept failed...\n");
        exit(0);
    } else
        printf("Server accepted the client...\n");

    // Handle client requests
    while (1) {
        char buff[MAX];
        bzero(buff, MAX);
        read(connfd, buff, sizeof(buff));
        int choice;
        sscanf(buff, "%d", &choice);

        switch (choice) {
            case 1:
                chat(connfd);
                break;
            case 2:
                perform_calculation(connfd);
                break;
            case 3:
                close(connfd);
                close(sockfd);
                exit(0);
            default:
                snprintf(buff, sizeof(buff), "Invalid option");
                write(connfd, buff, strlen(buff));
                break;
        }
    }

    return 0;
}

